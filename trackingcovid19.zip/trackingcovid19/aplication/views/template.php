
<!DOCTYPE html>
<html lang="en" dir="ltr">
<!-- Copied from https://kawalcorona.com/ by Cyotek WebCopy 1.7.0.600, Wednesday, 25 March 2020, 01:06:38 -->
	<head>

		<!-- META DATA -->
		<title><?php echo $title; ?> | Tracking_Covid-19</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  		<link rel="shortcut icon" href="<?php echo base_url('assets/'); ?>uploads/icon.png">
		<!-- BOOTSTRAP CSS -->
		<link href="<?php echo base_url('assets/'); ?>data/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">

		<!-- STYLE CSS -->
		<link href="<?php echo base_url('assets/'); ?>data/css/newstyle.css" rel="stylesheet">
		<link href="<?php echo base_url('assets/'); ?>data/css/skin-modes.css" rel="stylesheet">

		<!--HORIZONTAL CSS-->
		<link href="<?php echo base_url('assets/'); ?>data/plugins/horizontal-menu/horizontal-menu.css" rel="stylesheet">

		<!-- CUSTOM SCROLL BAR CSS-->
		<link href="<?php echo base_url('assets/'); ?>data/plugins/scroll-bar/jquery.mCustomScrollbar.css" rel="stylesheet">

		<!--- FONT-ICONS CSS -->
		<link href="<?php echo base_url('assets/'); ?>data/css/icons.css" rel="stylesheet">

		<!-- SIDEBAR CSS -->
		<link href="<?php echo base_url('assets/'); ?>data/plugins/sidebar/sidebar.css" rel="stylesheet">

		<!-- COLOR SKIN CSS -->
		<link id="theme" rel="stylesheet" type="text/css" media="all" href="<?php echo base_url('assets/'); ?>data/colors/color1.css">
	</head>

	<body>

		<!-- PAGE -->
		<div class="page">
			<div class="page-main">

            <?php echo $_content; ?>

			<!-- FOOTER -->
			<footer>
			<div class="footer border-top-0 footer-1">
										<div class="container">
											<div class="row align-items-center">
												<div class="col-lg-12 col-sm-12 mt-3 mt-lg-0 text-center">
													<br><a href="javascript:;"><img src="<?php echo base_url('assets/uploads/logo.png'); ?>" alt="Ethical Hacker Indonesia" width="172" height="45"></a><br><br>
													<?php echo date('Y'); ?> Tracking Covid-19 by <a href="">Muhammad Hilmy Taufik</a>. Made with <i class="fa fa-heart"></i> by <a href="https://teguh.co" target="_blank">Teguh Aprianto</a>
												</div>
											</div>
										</div>
									</div>
								</footer></div>
							</div><!-- COL-END -->
						
			
			<!-- FOOTER END -->
		

		<!-- JQUERY JS -->
		<script src="<?php echo base_url('assets/'); ?>data/js/jquery-3.4.1.min.js"></script>

		<!-- BOOTSTRAP JS -->
		<script src="<?php echo base_url('assets/'); ?>data/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
		<script src="<?php echo base_url('assets/'); ?>data/plugins/bootstrap/js/popper.min.js"></script>

		<!-- INPUT MASK JS -->
		<script src="<?php echo base_url('assets/'); ?>data/plugins/input-mask/jquery.mask.min.js"></script>

        <!-- CUSTOM SCROLLBAR JS -->
		<script src="<?php echo base_url('assets/'); ?>data/plugins/scroll-bar/jquery.mCustomScrollbar.concat.min.js"></script>

		<!-- SIDE-MENU JS -->
		<script src="<?php echo base_url('assets/'); ?>data/plugins/horizontal-menu/horizontal-menu.js"></script>

		<!-- SIDEBAR JS -->
		<script src="<?php echo base_url('assets/'); ?>data/plugins/sidebar/sidebar.js"></script>

		<!-- INDEX JS -->
        <script src="<?php echo base_url('assets/'); ?>data/js/index21.js"></script>
		
		<!-- STICKY JS -->
		<script src="<?php echo base_url('assets/'); ?>data/js/stiky.js"></script>

		<!--CUSTOM JS -->
		<script src="<?php echo base_url('assets/'); ?>data/js/custom.js"></script>

	<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="396f5e0f54dcc4033c0fcc31-|49" defer=""></script></body>
<!-- Copied from https://kawalcorona.com/ by Cyotek WebCopy 1.7.0.600, Wednesday, 25 March 2020, 01:06:38 -->
</html>